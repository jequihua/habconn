\"\"\"Base feature extractor interfaces.\"\"\"
