\"\"\"Small benchmark experiment definitions.\"\"\"
