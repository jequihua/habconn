\"\"\"Policy evaluation utilities.\"\"\"
