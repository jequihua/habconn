\"\"\"Logging setup utilities.\"\"\"
