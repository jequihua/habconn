\"\"\"Profiling and timing helpers.\"\"\"
