\"\"\"Episode termination conditions.\"\"\"
