\"\"\"Core optimization problem interfaces.\"\"\"
